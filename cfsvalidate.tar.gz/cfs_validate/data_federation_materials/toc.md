## CFS QUESTIONNAIRE
https://www.census.gov/programs-surveys/cfs/technical-documentation/questionnaires.html

I'd recommend checking out the instructions and questionnaire here. Specifically, what we're looking at is Item F, the place where users actually dump their list of shipments. To respond by uploading a spreadsheet, respondents downloaded a template spreadsheet that basically looks exactly like the Item F table on the questionnaire itself. (Just without the pagination). If it'd be helpful, I can find the blank .xlsx file lying around somewhere.

## BACKGROUND UI/UX INFORMATION
- FILE NAME: **2017 CFS (Main) Survey Centurion specifications.docx**
- DESCRIPTION: Contains, among other things, screenshots of how survey respondents using the web UI filled out the CFS in 2017. Of primary importance here is, starting on page 13, the screenshots essentially detailing the current XLSX file upload process for the shipment records.


- FILE NAMES: **user_research/\*.pdf**
- DESCRIPTION: These four files come from user research done in advance of the 2017 CFS. We are currently undertaking further research to learn more about companies' data storage habits and what would be easiest for them, but this is a start and may be useful background information. 


## VALIDATION SPECS
#### Important definition: "edits" are the flags / rule-based checks that have been programmatically implemented.
- FILE NAME: **2017 CFS Batch and Interactive Edits Spec.docx**
- DESCRIPTION: Contains all "edit" (i.e. flag) specifications used in the 2017 CFS. Respondents didn't see these, so this is all of the programmatic, rule-based flags we've set up, which essentially informs everything we do on the backend to clean up respondents' data. Specifically, for this project, we care about the "Shipment" edits S1-S17. The below file ("2017 Edit Summary Table") also includes a useful tab summarizing each edit if you don't wnat to go through this entire doc.


- FILE NAME: **2017 Edit Summary Tables 2-15-18.xlsx**
- DESCRIPTION: For each edit in the above spec file, this shows how many records in the current 2017 data are passing/failing the edit. This sheet also has a handy tab "Shipment Edit Key" that summarizes each edit.


- FILE NAME: **lkup_rules/\*.xlsx**
- DESCRIPTION: A number of the edits involve reasonably involved lookup tables (e.g. certain SCTG codes should -- in theory -- only be shipped by companies within certain NAICS codes). Those all live here.


## SAMPLE DATA
- FILE NAMES: **data/shipment_test_v3.csv**
- DESCRIPTION: Includes a long list of synthetically generated data, many rows of which fail one or several of the above edits