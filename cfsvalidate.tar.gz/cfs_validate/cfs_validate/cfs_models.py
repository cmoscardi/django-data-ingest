from django import forms
from django.db import models

import data_ingest.forms
import data_ingest.models

class CFSUploadForm(data_ingest.forms.UploadForm):
    establishment_id_or_nickname = forms.CharField(max_length=40)
    reporting_periods = forms.SelectMultiple(choices=["Q1",
                                                       "Q2",
                                                       "Q3",
                                                       "Q4"])
    reporting_timeframe = forms.CharField(max_length=40)



class CFSUploadItem(models.Model):
    year = models.IntegerField()
    agency = models.TextField()
    data_source = models.TextField()

    ship_month = models.IntegerField()
    ship_day = models.IntegerField()
    ship_value = models.IntegerField()
    ship_weight = models.IntegerField()
    ship_desc = models.TextField()
    ship_tc = models.TextField()
    ship_unna = models.TextField()
    ship_city = models.TextField()
    ship_state = models.TextField()
    ship_zip = models.TextField()
    ship_mode = models.TextField()

    upload = models.ForeignKey(data_ingest.models.DefaultUpload)
    row_number = models.IntegerField()
